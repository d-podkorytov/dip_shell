% Common interfaces for communication by pipes with files, networks , databases and others things.
-module(pipes).
-compile(export_all).

open_file(FileName,Opt)->
 {ok,F}=file:open(FileName,Opt),F.

close_file(F)->
 file:close(F).

write_file(F,Bin)->
 file:write(F,Bin).
 
read_file(F)->
 file:read(F).

% File->Pid
read_file(F,Pid)->
 case read_file(F) of
 eof -> close_file(F);
 Bin -> Pid!{self(),Bin}, 
        read_file(F,Pid)
 end.

% Pid -> File
write_file(F,Pid,F1)->
receive
{Pid,Bin} -> case F1(Pid) of
              false -> ok;
              true  -> write_file(F,Bin)
             end;
_         -> ok 
end,
write_file(F,Pid,F1).

start(FileName,Opt)->
 spawn(fun()-> loop(open_file(FileName,Opt)) end).

loop(F) ->
 receive
 {From,{Mod,Fun,Arg}} -> From! {self(),try Mod:Fun(Arg) of
                                       R->R
                                       catch
                                        Err:Reason -> {catch_in_try,Err,Reason,Mod,Fun,Arg}   
                                       end 
                               }
 end,
 loop(F).
 